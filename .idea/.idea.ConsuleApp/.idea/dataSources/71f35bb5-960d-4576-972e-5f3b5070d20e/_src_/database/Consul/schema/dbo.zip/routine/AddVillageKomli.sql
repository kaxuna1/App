-- =============================================
-- Author:		Kakha Gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[AddVillageKomli]
@VillageId int,
@UserId int,
@Komli INT,
@ValidFrom DATE
AS
BEGIN

	INSERT INTO dbo.VillageData
	(
	    villageId,
	    komli,
	    createdBy,
	    createDate,
	    accepted,
	    declined,
	    lastModifyBy,
	    lastModifyDate,
		validFrom
	)
	VALUES
	(   @VillageId,         -- villageId - int
	    @Komli,         -- komli - int
	    @UserId,         -- createdBy - int
	    GETDATE(), -- createDate - datetime
	    0,         -- accepted - int
	    0,         -- declined - int
	    @UserId,         -- lastModifyBy - int
	    GETDATE(),  -- lastModifyDate - datetime
		@ValidFrom
	)
END
GO
