-- =============================================
-- Author:		Kakha Gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[AddBranchStatus]
@BranchId int,
@UserId int,
@StatusId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	
	INSERT INTO Consul.dbo.BranchStatuses
	(
	    branchId,
	    createDate,
	    createdBy,
	    status,
	    lastModifyDate,
	    accepted,
		lastModifyBy,
		declined
	)
	VALUES
	(   @BranchId,         -- branchId - int
	    GETDATE(), -- createDate - datetime
	    @UserId,         -- createdBy - int
	    @StatusId,         -- status - int
	    GETDATE(), -- lastModifyDate - datetime
	    0,
		@UserId,
		0)
	
	
	--.[dbo].(branchId,createDate,createdBy,status,lastModifyDate

END
GO
