-- =============================================
-- Author:		kaxa gelashvili
-- Create date: 20.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[getOfficers]
	-- Add the parameters for the stored procedure here
	@BranchId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT lo.Id,p.PersonalN,lo.BranchId,p.FullName FROM CredoBnk.dbo.TBL_LoanOfficer lo
	JOIN CredoBnk.dbo.TBL_Person p ON lo.PersonId = p.Id
	WHERE lo.BranchId=@BranchId AND lo.Active=1
END
GO
