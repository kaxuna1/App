-- =============================================
-- Author:		Kakha Gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[AcceptVillageMimartuleba]
@Id INT,
@UserId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	
	UPDATE dbo.VillageMimartuleba SET accepted = 1,lastModifyBy=@UserId,lastModifyDate=GETDATE() WHERE
    id=@Id

END
GO
