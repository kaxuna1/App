-- =============================================
-- Author:		Kakha Gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[DeclineBranchStatus]
@Id INT,
@UserId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	
	UPDATE dbo.BranchStatuses SET declined = 1,lastModifyBy=@UserId,lastModifyDate=GETDATE() WHERE
    id=@Id AND accepted = 0

END
GO
