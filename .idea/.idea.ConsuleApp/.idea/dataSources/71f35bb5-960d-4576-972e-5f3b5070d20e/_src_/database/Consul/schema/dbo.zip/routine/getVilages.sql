-- =============================================
-- Author:		kaxa gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[getVilages]
	-- Add the parameters for the stored procedure here
	@branchId INT,
	@date DATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select v.*,st.*,
	dbo.GetAvailableKomliForVilage(v.Id,@date) AS komliLeft,
	dbo.GetMimartulebaForVilage(v.Id,@date) AS mimartuleba
	FROM CredoBnk.dbo.TBL_Village v
	outer apply (
	select top 1 komli,accepted,declined,lastModifyDate,per1.FullName lastModifyBy,per2.FullName createdBy
	
	FROM [dbo].VillageData vd
	LEFT JOIN CredoAuth.dbo.Users us1 on us1.UserId = vd.lastModifyBy
	LEFT join CredoAuth.dbo.Users us2 on us2.UserId = vd.createdBy
	LEFT JOIN CredoBnk.dbo.TBL_Person per1 ON per1.Id = us1.PersonId
	LEFT JOIN CredoBnk.dbo.TBL_Person per2 ON per2.Id = us2.PersonId
	WHERE vd.villageId = v.Id AND vd.declined=0 AND vd.validFrom<=@date  order BY vd.validFrom DESC, vd.createDate desc
    
	) as st
	 where v.Active= 1 AND v.BranchId=@branchId
END
GO
