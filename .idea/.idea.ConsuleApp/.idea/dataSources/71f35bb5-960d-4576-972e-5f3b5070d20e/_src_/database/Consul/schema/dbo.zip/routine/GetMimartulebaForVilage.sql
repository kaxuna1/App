-- =============================================
-- Author:		kaxa gelashvili
-- Create date: 9.25.2017
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[GetMimartulebaForVilage] 
(	
	-- Add the parameters for the function here
	@VillageId INT,
	@date DATE
)
RETURNS Integer 
AS
BEGIN

	
	DECLARE @mimartuleba INT = (SELECT TOP 1 mimartuleba FROM dbo.VillageMimartuleba WHERE vilageId = @VillageId
	AND validFrom <=@date ORDER BY  validFrom DESC)
	RETURN @mimartuleba
end
GO
