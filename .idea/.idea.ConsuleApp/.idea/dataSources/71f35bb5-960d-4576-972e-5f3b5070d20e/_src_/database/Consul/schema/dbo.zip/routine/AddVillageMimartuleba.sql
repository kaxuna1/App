-- =============================================
-- Author:		Kakha Gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[AddVillageMimartuleba]
@VilageId int,
@UserId int,
@MimartulebaId INT,
@validFrom DATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	
	INSERT INTO dbo.VillageMimartuleba
	(
	    vilageId,
	    createdBy,
	    createDate,
	    accepted,
	    declined,
	    lastModifyBy,
	    lastModifyDate,
	    mimartuleba,
		validFrom
	)
	VALUES
	(   @VilageId,         -- vilageId - int
	    @UserId,         -- createdBy - int
	    GETDATE(), -- createDate - datetime
	    0,         -- accepted - int
	    0,         -- declined - int
	    @UserId,         -- lastModifyBy - int
	    GETDATE(), -- lastModifyDate - datetime
	    @MimartulebaId,          -- mimartuleba - int
		@validFrom
	)
END
GO
