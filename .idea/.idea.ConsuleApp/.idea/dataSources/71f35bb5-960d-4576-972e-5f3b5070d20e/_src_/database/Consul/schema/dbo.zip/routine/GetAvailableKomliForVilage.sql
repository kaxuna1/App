-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[GetAvailableKomliForVilage] 
(	
	-- Add the parameters for the function here
	@VillageId INT,
	@date DATE
)
RETURNS Integer 
AS
BEGIN
	DECLARE @komli INT = (SELECT TOP 1 vd.komli FROM dbo.VillageData vd 
	WHERE vd.villageId = @VillageId AND 
	vd.accepted=1 AND 
	vd.validFrom<=@date 
	ORDER BY vd.validFrom desc, vd.createDate desc)

	 DECLARE @komliLeft INT = (SELECT SUM(f.komli) FROM (SELECT DISTINCT ov.officerId,v.komli AS komli,v.validFrom FROM dbo.OfficerVillages ov 
	 CROSS APPLY(SELECT TOP 1 * FROM dbo.OfficerVillages va WHERE officerId = ov.officerId
	 AND va.validFrom<=@date
	 ORDER BY ov.validFrom desc,ov.createDate DESC) AS v
	 WHERE ov.villageId=@VillageId)  AS f)


	 return @komli-ISNULL(@komliLeft,0)
end
GO
