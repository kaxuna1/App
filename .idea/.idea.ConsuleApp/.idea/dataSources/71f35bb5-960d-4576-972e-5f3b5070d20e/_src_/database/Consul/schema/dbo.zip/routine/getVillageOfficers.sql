-- =============================================
-- Author:		kaxa gelashvili
-- Create date: 20.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[getVillageOfficers]
	-- Add the parameters for the stored procedure here
	@VillageId INT,
	@Date DATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		SELECT DISTINCT ov.officerId,v.komli AS komli,v.validFrom,p.FullName FROM dbo.OfficerVillages ov 
		CROSS APPLY(SELECT TOP 1 * FROM dbo.OfficerVillages va 
		WHERE officerId = ov.officerId
		AND va.validFrom<=@Date
		ORDER BY ov.validFrom desc,ov.createDate DESC) AS v
		JOIN CredoBnk.dbo.TBL_LoanOfficer lo ON lo.id=ov.officerId
		JOIN CredoBnk.dbo.TBL_Person p ON lo.PersonId = p.Id
		WHERE ov.villageId=@VillageId
END
GO
