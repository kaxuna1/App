-- =============================================
-- Author:		kaxa gelashvili
-- Create date: 19.9.2017
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[GetAvailableKomliCountForVilage]
	-- Add the parameters for the stored procedure here
	@VillageId INT,
	@date DATE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @komli INT = (SELECT TOP 1 vd.komli FROM dbo.VillageData vd 
	WHERE vd.villageId = @VillageId AND 
	vd.accepted=1 AND 
	vd.validFrom<=@date 
	ORDER BY vd.validFrom desc, vd.createDate desc)

	 DECLARE @komliLeft INT = (SELECT SUM(f.komli) FROM (SELECT DISTINCT ov.officerId,v.komli AS komli,v.validFrom FROM dbo.OfficerVillages ov 
	 CROSS APPLY(SELECT TOP 1 * FROM dbo.OfficerVillages va WHERE officerId = ov.officerId
	 AND va.validFrom<=@date
	 ORDER BY ov.validFrom desc,ov.createDate DESC) AS v
	 WHERE ov.villageId=@VillageId)  AS f)


	 SELECT @komli-@komliLeft
END


GO
