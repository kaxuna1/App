-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getBranches]
	-- Add the parameters for the stored procedure here

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select b.*,st.*,cti.City,reg.Region,bsn.name AS statusName FROM CredoBnk.dbo.TBL_Branch b
	outer apply (
	SELECT TOP 1 status,accepted,vd.createDate AS statusCreateDate,vd.lastModifyDate AS statusModifyDate
	,per1.FullName lastModifyBy,per2.FullName createdBy from [dbo].[BranchStatuses]  vd
	join CredoAuth.dbo.Users us1 on us1.UserId = vd.lastModifyBy
	join CredoAuth.dbo.Users us2 on us2.UserId = vd.createdBy
	JOIN CredoBnk.dbo.TBL_Person per1 ON per1.Id = us1.PersonId
	JOIN CredoBnk.dbo.TBL_Person per2 ON per2.Id = us2.PersonId
	WHERE vd.branchId = b.Id order by vd.createDate desc
	) as st
	JOIN CredoBnk.dbo.TBL_City cti ON cti.Id = b.CityId
	JOIN CredoBnk.dbo.TBL_Region reg ON reg.Id = b.RegionId
	
	LEFT JOIN dbo.BranchStatusNames bsn ON bsn.id=st.status
	where b.Active= 1
END
GO
